# Andreas Hadji App

Android app for Andreas Hadjipanayiotou, designed around a 430x932 mobile viewport.

## Features
- Demos / Lyrics / Releases / Biography
- Admin button with PIN protection
- Add demo MP3 directly from the Android device using the system file picker
- Local storage of imported MP3 files
- Audio playback
- Add/edit/delete content from the Admin area
- GitHub Actions workflow for building the APK

## GitHub APK build
Push the project to the `main` branch or manually run **Actions → Build Android APK → Run workflow**.
The APK is published as the `AndreasHadji-debug-apk` artifact.

Default admin PIN: `1234`
